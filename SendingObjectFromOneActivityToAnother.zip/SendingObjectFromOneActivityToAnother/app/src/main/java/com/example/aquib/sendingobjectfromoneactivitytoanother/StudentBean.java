package com.example.aquib.sendingobjectfromoneactivitytoanother;

import java.io.Serializable;

/**
 * Created by Aquib on 29/8/17.
 *
 */

/**
 * we have to make it implement Serializable in order to send it from one activity to another
 * without making it implement Serializable its not possible to send it from activity to another
 */
 class StudentBean implements Serializable {

    private String Name;
    private String Roll;

     StudentBean(String name, String roll) {
        Name = name;
        Roll = roll;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getRoll() {
        return Roll;
    }

    public void setRoll(String roll) {
        Roll = roll;
    }


}
