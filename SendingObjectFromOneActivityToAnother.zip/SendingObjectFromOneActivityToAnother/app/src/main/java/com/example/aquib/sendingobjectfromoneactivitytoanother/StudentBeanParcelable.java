package com.example.aquib.sendingobjectfromoneactivitytoanother;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Aquib on 30/8/17.
 *
 */

/**
 * why to use Parcelable over Serializable
 * 1. Parcelable is well documented in the Android SDK; serialization on the other hand is available in Java.
 *    It is for this very reason that Android developers prefer Parcelable over the Serialization technique.
 *
 * 2. In Parcelable, developers write custom code for marshaling and unmarshaling so it creates less garbage objects in comparison to Serialization.
 *    The performance of Parcelable over Serialization dramatically improves (around two times faster),
 *    because of this custom implementation.
 *                                          Serialization is a marker interface, which implies the
 *    user cannot marshal the data according to their requirements.In Serialization, a marshaling operation is performed
 *    on a Java Virtual Machine (JVM) using the Java reflection API.This helps identify the Java objects member and
 *    behavior, but also ends up creating a lot of garbage objects.Due to this, the Serialization process is slow
 *    in comparison to Parcelable.
 *
 */

public class StudentBeanParcelable implements Parcelable{


    private String Name;
    private String Roll;

    // Constructor

    StudentBeanParcelable(String name, String roll) {
        Name = name;
        Roll = roll;
    }

    // Getter and setter methods
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getRoll() {
        return Roll;
    }

    public void setRoll(String roll) {
        Roll = roll;
    }

    // Parcelling part
    /**
     * Use when reconstructing User object from parcel
     * This will be used only by the 'CREATOR'
     * @param in a parcel to read this object
     */
    protected StudentBeanParcelable(Parcel in) {
        Name = in.readString();
        Roll = in.readString();
    }


    /**
     * This field is needed for Android to be able to
     * create new objects, individually or as arrays
     *
     * If you don’t do that, Android framework will through exception
     * Parcelable protocol requires a Parcelable.Creator object called CREATOR
     */
    public static final Creator<StudentBeanParcelable> CREATOR = new Creator<StudentBeanParcelable>() {
        @Override
        public StudentBeanParcelable createFromParcel(Parcel in) {
            return new StudentBeanParcelable(in);
        }

        @Override
        public StudentBeanParcelable[] newArray(int size) {
            return new StudentBeanParcelable[size];
        }
    };


    /**
     * Define the kind of object that you gonna parcel,
     * You can use hashCode() here
     */
    @Override
    public int describeContents() {
        return 0;
    }


    /**
     * Actual object serialization happens here, Write object content
     * to parcel one by one, reading should be done according to this write order
     * @param parcel parcel
     * @param flags Additional flags about how the object should be written
     */
    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(Name);
        parcel.writeString(Roll);
    }
}
