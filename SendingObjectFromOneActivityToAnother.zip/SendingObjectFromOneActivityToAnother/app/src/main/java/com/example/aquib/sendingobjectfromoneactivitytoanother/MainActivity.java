package com.example.aquib.sendingobjectfromoneactivitytoanother;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<StudentBean> student = new ArrayList<>();
    private ArrayList<StudentBeanParcelable> studentParse = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView hello = (TextView) findViewById(R.id.hello);

        StudentBean mStudentBean1 = new StudentBean("Rohan1", "11");
        StudentBean mStudentBean2 = new StudentBean("Rohan2", "12");
        StudentBean mStudentBean3 = new StudentBean("Rohan3", "13");
        StudentBean mStudentBean4 = new StudentBean("Rohan4", "14");

        student.add(mStudentBean1);
        student.add(mStudentBean2);
        student.add(mStudentBean3);
        student.add(mStudentBean4);

        StudentBeanParcelable mStudentBeanParcelable1 = new StudentBeanParcelable("Rohan1", "11");
        StudentBeanParcelable mStudentBeanParcelable2 = new StudentBeanParcelable("Rohan2", "12");
        StudentBeanParcelable mStudentBeanParcelable3 = new StudentBeanParcelable("Rohan3", "13");
        StudentBeanParcelable mStudentBeanParcelable4 = new StudentBeanParcelable("Rohan4", "14");

        studentParse.add(mStudentBeanParcelable1);
        studentParse.add(mStudentBeanParcelable2);
        studentParse.add(mStudentBeanParcelable3);
        studentParse.add(mStudentBeanParcelable4);

        hello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //using Serializable

                /*Intent i=new Intent(MainActivity.this,Main2Activity.class);
                i.putExtra("QuestionListExtra",student);
                i.putExtra("String","Got String without bundle");
                startActivity(i);*/

                //or By using bundle and Serializable

                /*Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                Bundle args = new Bundle();
                args.putSerializable("Array",student);
                args.putString("String","Got String in bundle");
                intent.putExtra("BUNDLE",args);
                startActivity(intent);*/

                // using Parcelable recommended in android

                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                intent.putParcelableArrayListExtra("QuestionListExtra", studentParse);
                startActivity(intent);
            }
        });

    }
}
