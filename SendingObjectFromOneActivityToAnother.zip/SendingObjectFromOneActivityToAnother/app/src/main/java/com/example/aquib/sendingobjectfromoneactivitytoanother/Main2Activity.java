package com.example.aquib.sendingobjectfromoneactivitytoanother;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView text = (TextView) findViewById(R.id.data);
        TextView text1 = (TextView) findViewById(R.id.data1);

        //Intent intent = getIntent();

        // Without using Bundle and using Serializable

        /*ArrayList<StudentBean> object = (ArrayList<StudentBean>) intent.getSerializableExtra("QuestionListExtra");
        assert object != null;
        text.setText(object.get(2).getName());
        text1.setText(intent.getStringExtra("String"));*/


        // By using Bundle and using Serializable

        /*Bundle args = intent.getBundleExtra("BUNDLE");
        ArrayList<StudentBean> object = (ArrayList<StudentBean>) args.getSerializable("Array");
        assert object != null;
        text.setText(object.get(2).getName());
        text1.setText(args.getString("String"));*/

//        /*Bundle data = getIntent().getExtras();
//        StudentBeanParcelable student = (StudentBeanParcelable) data.getParcelable("student");
//        text.setText(student.getName());*/

        //Using Parcelable
        Intent data = getIntent();
        ArrayList<StudentBeanParcelable> object = data.getParcelableArrayListExtra ("QuestionListExtra");
        assert object != null;
        text.setText(object.get(0).getName());
        //text1.setText(intent.getStringExtra("String"));
    }
}
